package no.hvl.dat100ptc.oppgave1;

import no.hvl.dat100ptc.TODO;

public class GPSPoint {

	// TODO - objektvariable
		
	public GPSPoint(int time, double latitude, double longitude, double elevation) {

		// TODO - konstruktur

		throw new UnsupportedOperationException(TODO.construtor("GPSPoint"));

	}

	// TODO - get/set metoder
	public int getTime() {
		
		throw new UnsupportedOperationException(TODO.method());
		
	}

	public void setTime(int time) {
				
		throw new UnsupportedOperationException(TODO.method());

	}

	public double getLatitude() {
		
		throw new UnsupportedOperationException(TODO.method());
		
	}

	public void setLatitude(double latitude) {
		
		throw new UnsupportedOperationException(TODO.method());
		
	}

	public double getLongitude() {
		
		throw new UnsupportedOperationException(TODO.method());
		
	}

	public void setLongitude(double longitude) {
		
		throw new UnsupportedOperationException(TODO.method());
		
	}

	public double getElevation() {
		
		throw new UnsupportedOperationException(TODO.method());
		
	}

	public void setElevation(double elevation) {
		
		throw new UnsupportedOperationException(TODO.method());
		
	}
	
	public String toString() {
		
		String str;
		
		// TODO - start

		throw new UnsupportedOperationException(TODO.method());

		// TODO - slutt
		
	}
}
